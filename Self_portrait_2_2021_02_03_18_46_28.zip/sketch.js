function preload() {
  let shapes;
  img = loadImage('Ai-Background-Color geometry.jpg');
}
function setup() {
  createCanvas(800, 800);
  let shapes;
  
   colorMode(RGB);
  
  frameRate(2);
}

let value = 'skyBlue';
function mouseClicked() {
  if (true) {
    value = color(random(255), random(255), random(255));
  } else {
    value = 'skyBlue';
  }
}
function draw() {
  image(img,0, 0, 1280, 800);
  
  fill(value);
  triangle(659, 0, 746, 0, 746, 85);
  
  fill(random(255),random(255),random(255));
  triangle(119, 100, 210, 100, 210, 188)
  fill(random(255),random(255),random(255));
  triangle(90, 305, 280, 305, 90, 476)
  fill(random(255),random(255),random(255));
  triangle(210, 643, 210, 815, 387, 643)
  fill(random(255),random(255),random(255));
  triangle(-15, 643, 90, 643, 90, 745)
  fill(random(255),random(255),random(255));
  triangle(0, -20, 69, 51, 0, 51)
  fill(random(255),random(255),random(255));
  triangle(493, 643, 715, 643, 603, 751)
  fill(random(255),random(255),random(255));
  triangle(747, 168, 747, 306, 602, 306)
  fill(random(255),random(255),random(255));
  triangle(494, 50, 494, 163, 610, 50)
  fill(random(255),random(255),random(255));
  triangle(728, 440, 800, 368, 800, 508)
  
  //Skin
  noStroke();
  fill(135, 105, 95);
  circle(400, 300, 400);
  fill(215, 150, 110)
  rect(200, 300, 400, 150);
  bezier(600, 450, 600, 530, 450, 680, 420, 690);
  bezier(200, 450, 200, 530, 350, 680, 380, 690);
  quad(200, 450, 600, 450, 430, 690, 370, 690);
  
  //Hair
  fill(30, 25, 25);
  arc(400, 651, 140, 90, 0, 180);
  //Facial hair
  fill( 30, 25, 25, 150)
  beginShape();
  vertex(360, 585);
  bezierVertex(380, 584, 390, 594, 400, 594);//Nstrl R Shadow
  bezierVertex(410, 594, 420, 584, 440, 585);
  endShape();
  noFill();
  stroke(30, 25, 25, 150);
  strokeWeight( 20)
  curve(250, 780, 300, 550, 500, 550, 550, 780);
  noStroke();
  
  //Eyes
  fill(255)
  ellipse(300, 360, 90, 40);
  ellipse(500, 360, 90, 40);
  fill(55, 90, 105)
  circle(300, 355, 45); //Iris B
  circle(500, 355, 45);
  fill(95, 120, 50)
  circle(300, 355, 35); //Iris G
  circle(500, 355, 35);
  fill(0)
  circle(300, 355, 18); //Pupil
  circle(500, 355, 18);
  
  //Nose
  fill( 205, 130, 90)
  beginShape();
  vertex(340, 330);
  bezierVertex(370, 345, 360, 400, 346, 420);// Nose bridge shadow L
  bezierVertex(346, 420, 370, 355, 340, 330);
  endShape();
  fill(205, 130, 90)
  beginShape();
  vertex(460, 330);
  bezierVertex(430, 345, 440, 400, 454, 420);// Nose briidge shadow R
  bezierVertex(454, 420, 430, 355, 460, 330);
  endShape();
  
  fill( 215, 150, 110)
  beginShape();
  vertex(254, 360);
  bezierVertex(254, 300, 345, 300, 346, 360);
  bezierVertex(346, 335, 255, 335, 254, 360);
  endShape();
  fill(215, 150, 110)
  beginShape();
  vertex(454, 360);
  bezierVertex(454, 300, 545, 300, 546, 360);
  bezierVertex(546, 335, 455, 335, 454, 360);
  endShape();
  
  fill( 205, 130, 90)
  beginShape();
  vertex(254, 345);
  bezierVertex(264, 320, 355, 300, 356, 360); //Eye shadow L
  bezierVertex(346, 310, 255, 335, 254, 345);
  endShape();
  fill(205, 130, 90)
  beginShape();
  vertex(546, 345);
  bezierVertex(546, 320, 445, 300, 446, 360); // Eye shadow R
  bezierVertex(454, 310, 545, 335, 546, 345);
  endShape();
   
  //Lips 
  angleMode( DEGREES);
  fill( 245, 150, 155);
  arc(400, 560, 160, 40, 0, 180);
  
  fill( 200, 100, 110);
  bezier( 320, 560, 325, 560, 380, 515, 410, 560);
  bezier( 480, 560, 475, 560, 420, 515, 390, 560);
  
  //Skin 
  fill( 215, 150, 110);
  arc(400, 649, 140, 25, 0, 180);
  fill( 235, 170, 130);
  bezier( 265)
  
  //Nose
  fill( 205, 130, 90)
  beginShape();
  vertex(341, 500);
  bezierVertex(325, 485, 333, 465, 350, 450);//Nstrl L Shadow
  bezierVertex(350, 450, 331, 480, 338, 492);
  endShape();
  
  beginShape();
  vertex(459, 500);
  bezierVertex(477, 485, 467, 465, 450, 450);//Nstrl R Shadow
  bezierVertex(450, 450, 469, 480, 462, 492);
  endShape();
  fill( 205, 130, 90)
  ellipse(363, 489, 41, 23); //Nstrl L shadow lil
   fill( 70, 50, 55)
  ellipse(363, 493, 35, 15); //Nstrl L 
  fill( 205, 130, 90)
  ellipse(437, 489, 41, 23); //Nstrl R shadow lil
   fill( 70, 50, 55)
  ellipse(437, 493, 35, 15); //Nstrl R
  fill( 205, 130, 90)
  ellipse(400, 480, 60, 45); //shadow mid
  fill( 215, 150, 110)
  ellipse(400, 467, 45, 60); //skin mid
  
  fill( 215, 150, 110)
  beginShape();
  vertex(341, 491);
  bezierVertex(345, 440, 385, 430, 387, 491);//Nstrl L Shadow
  bezierVertex(387, 474, 341, 474, 341, 491);
  endShape();
  
  beginShape();
  vertex(459, 491);
  bezierVertex(452, 440, 417, 430, 415, 491);//Nstrl R Shadow
  bezierVertex(415, 474, 461, 474, 459, 491);
  endShape();
  
  //Ears
  fill(215, 150, 110)
  ellipse(190, 400, 40, 100)
  ellipse(202, 440, 40, 100)
  
  fill(215, 150, 110)
  ellipse(610, 400, 40, 100)
  ellipse(598, 440, 40, 100)
  
  fill( 205, 130, 90)
  beginShape();
  vertex(200, 430);
  bezierVertex(195, 330, 172, 355, 176, 420); //Ear shadow L
  bezierVertex(176, 420, 182, 323, 197, 434);
  endShape();
  
  beginShape();
  vertex(200, 430);
  bezierVertex(195, 435, 182, 445, 197, 460); //Ear shadow L
  bezierVertex(188, 440, 198, 440, 200, 430);
  endShape();
  
  beginShape();
  vertex(600, 430);
  bezierVertex(605, 330, 628, 355, 624, 420); //Ear shadow R
  bezierVertex(624, 420, 618, 323, 603, 434);
  endShape();
  
  beginShape();
  vertex(600, 430);
  bezierVertex(605, 435, 618, 445, 603, 460); //Ear shadow R
  bezierVertex(612, 440, 602, 440, 600, 430);
  endShape();
  
  //Hair
  stroke(30, 25, 25);
  strokeWeight(15);
  line(595, 350, 595, 250);
  strokeWeight(28);
  line(567, 270, 567, 186);
  strokeWeight(31);
  line(531, 225, 531, 146);
  strokeWeight(35);
  line(489, 208, 489, 118);
  strokeWeight(35);
  line(445, 202, 445, 102);
  strokeWeight(37);
  line(400, 200, 400, 98); //Mid
  strokeWeight(35);
  line(355, 202, 355, 102);
  strokeWeight(35);
  line(311, 208, 311, 118);
  strokeWeight(31);
  line(269, 225, 269, 146);
  strokeWeight(28);
  line(233, 270, 233, 186);
  strokeWeight(15);
  line(205, 350, 205, 250);
  
  //Skin
  strokeWeight(0);
  fill(215, 150, 110);
  quad(198, 353, 216, 275, 260, 250, 220, 400);
  quad(602, 353, 584, 275, 540, 250, 580, 400);
  ellipse(400, 215, 300, 70);
  rect(250, 215, 300, 50)

  //Facial hair
  noFill();
  stroke(255, 102, 0);
  stroke(0, 0, 0);
  bezier(85, 20, 10, 10, 90, 90, 15, 80);
  
  //Skin
  fill( 215, 150, 110)
  triangle(270, 540, 305, 574, 325, 510 )
  triangle(530, 540, 495, 574, 475, 510 )
  ellipse(400, 510, 25, 13)
  
  fill( 30, 25, 25, 220)
  beginShape();
  vertex(240, 335);
  bezierVertex(255, 300, 370, 285, 360, 340);//Eyebrow L
  bezierVertex(350, 315, 270, 315, 240, 335);
  endShape();
  beginShape();
  vertex(560, 335);
  bezierVertex(545, 300, 430, 285, 440, 340);//Eyebrow R
  bezierVertex(450, 315, 530, 315, 560, 335);
  endShape();
  fill(215, 150, 110)
  quad(240, 303, 247, 260, 553, 260, 560, 303);
  
  fill(255)
  circle(307, 350, 5);
  circle(507, 350, 5); 
}